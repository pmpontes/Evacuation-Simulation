package tools;

public enum ToggleState {
	WALL, HERO, DART, DRAGON, SHIELD, SWORD, NONE, EXIT, PATH;
}
